library(testthat)
library(heatmapEco)

test_check("heatmapEco")
